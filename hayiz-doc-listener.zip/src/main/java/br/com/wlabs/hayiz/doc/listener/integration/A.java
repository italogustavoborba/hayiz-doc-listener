package br.com.wlabs.hayiz.doc.listener.integration;

public class A {
}
