package br.com.wlabs.hayiz.doc.listener.test;

public class A {
}
